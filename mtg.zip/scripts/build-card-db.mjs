
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { DECKS, parseDeckList } from "../src/cards/decks.js";

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const OUT=path.join(ROOT,"public","data");
fs.mkdirSync(OUT,{recursive:true});
const OVERRIDE_FILES=["custom-poseidon-overrides.json","custom-blech-overrides.json"];
const CUSTOM_OVERRIDES=Object.assign({},...OVERRIDE_FILES.map(file=>{const p=path.join(ROOT,"scripts",file);return fs.existsSync(p)?JSON.parse(fs.readFileSync(p,"utf8")):{};}));
function localCustomCard(name){
  const c=CUSTOM_OVERRIDES[name]; if(!c)return null;
  const typeLine=c.typeLine||"";
  const type=typeLine.includes("Land")?"Land":typeLine.includes("Creature")?"Creature":typeLine.includes("Artifact")?"Artifact":typeLine.includes("Enchantment")?"Enchantment":typeLine.includes("Planeswalker")?"Planeswalker":typeLine.includes("Instant")?"Instant":typeLine.includes("Sorcery")?"Sorcery":"Other";
  return {scryfallId:null,oracleId:null,name:c.name,image:c.image||"",artCrop:c.artCrop||"",manaCost:c.manaCost||"",manaValue:Number(c.manaValue||0),type,typeLine,power:c.power??null,toughness:c.toughness??null,loyalty:null,colors:[],colorIdentity:[],keywords:c.keywordsOrTags||[],oracleText:c.rulesSummary||"",producedMana:[],legalities:{commander:"custom"},interactions:[],isCustomCard:true};
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const SCRYFALL_HEADERS={
  "User-Agent":"MTGAITrainer/2.0 (+local educational deck trainer)",
  "Accept":"application/json"
};
const uniq=a=>[...new Set(a)];
function resolveCard(map,name){
  if(!name) return null;
  if(map?.[name]) return map[name];
  return Object.values(map||{}).find(c=>c?.name===name || c?.name?.startsWith(name+" //")) || null;
}

function normalize(c){
  const f=c.card_faces?.[0]||c;
  const tl=c.type_line||f.type_line||"";
  const type=tl.includes("Land")?"Land":tl.includes("Creature")?"Creature":tl.includes("Artifact")?"Artifact":tl.includes("Enchantment")?"Enchantment":tl.includes("Planeswalker")?"Planeswalker":tl.includes("Instant")?"Instant":tl.includes("Sorcery")?"Sorcery":"Other";
  return {
    scryfallId:c.id,oracleId:c.oracle_id,name:c.name,
    image:c.image_uris?.normal||c.card_faces?.[0]?.image_uris?.normal||"",
    artCrop:c.image_uris?.art_crop||c.card_faces?.[0]?.image_uris?.art_crop||"",
    manaCost:f.mana_cost||c.mana_cost||"",manaValue:Number(c.mana_value||0),
    type,typeLine:tl,power:f.power??null,toughness:f.toughness??null,loyalty:f.loyalty??null,
    colors:c.colors||f.colors||[],colorIdentity:c.color_identity||[],
    keywords:c.keywords||[],oracleText:f.oracle_text||c.oracle_text||"",
    producedMana:c.produced_mana||[],legalities:c.legalities||{},interactions:[]
  };
}
async function lookupNamed(name){
  const custom=localCustomCard(name);
  if(custom) return custom;

  const candidates=[name];
  if(name.includes(" // ")) candidates.push(name.split(" // ")[0]);
  for(const candidate of candidates){
    const url="https://api.scryfall.com/cards/named?exact="+encodeURIComponent(candidate);
    const r=await fetch(url,{headers:SCRYFALL_HEADERS});
    if(r.ok) return normalize(await r.json());
    if(r.status!==404){
      console.warn(`Scryfall named lookup for ${JSON.stringify(candidate)} returned ${r.status}; continuing.`);
    }
    await sleep(55);
  }
  console.warn(`Card not found on Scryfall and no local override exists: ${name}`);
  return null;
}

async function collection(names){
  const out={};
  const unique=uniq(names).filter(Boolean);

  // Custom/local-only cards must never be sent to Scryfall. A custom card in a
  // /cards/collection batch can cause the entire HTTP request to be rejected.
  const remote=[];
  for(const name of unique){
    const custom=localCustomCard(name);
    if(custom) out[name]=custom;
    else remote.push(name);
  }

  for(let i=0;i<remote.length;i+=75){
    const part=remote.slice(i,i+75);
    const r=await fetch("https://api.scryfall.com/cards/collection",{
      method:"POST",
      headers:{"Content-Type":"application/json","Accept":"application/json"},
      body:JSON.stringify({identifiers:part.map(name=>({name}))})
    });

    if(r.ok){
      const d=await r.json();
      for(const raw of d.data){
        const c=normalize(raw);
        out[c.name]=c;
        const requested=part.find(n=>n===c.name || c.name.startsWith(n+" //") || n.startsWith(c.name+" //"));
        if(requested) out[requested]=c;
      }
      // Scryfall can return a successful collection with individual misses.
      for(const name of part){
        if(!out[name]){
          const c=await lookupNamed(name);
          if(c) out[name]=c;
        }
      }
    } else {
      let detail="";
      try{detail=JSON.stringify(await r.json())}catch{}
      console.warn(`Scryfall batch returned ${r.status}. Falling back to individual lookups. ${detail}`);
      for(const name of part){
        const c=await lookupNamed(name);
        if(c) out[name]=c;
      }
    }
    await sleep(80);
  }
  return out;
}
async function search(q){
  const all=[];let url="https://api.scryfall.com/cards/search?q="+encodeURIComponent(q)+"&unique=cards&order=edhrec";
  while(url&&all.length<160){
    const r=await fetch(url,{headers:SCRYFALL_HEADERS});if(!r.ok)throw new Error(`Scryfall search failed ${r.status}`);
    const d=await r.json();all.push(...d.data.map(normalize));url=d.has_more?d.next_page:null;if(url)await sleep(80);
  }
  return all;
}
const nums={a:1,an:1,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
const qty=x=>(nums[String(x||"").toLowerCase()] ?? Number(x) ?? 1);

function compileEffect(text){
  const e=[];let m;
  if(/\bdraw (?:a|one) card\b/i.test(text))e.push({op:"DRAW",amount:1});
  if((m=text.match(/\bdraw (\d+) cards?/i)))e.push({op:"DRAW",amount:Number(m[1])});
  if((m=text.match(/you gain (\d+) life/i)))e.push({op:"GAIN_LIFE",amount:Number(m[1])});
  if((m=text.match(/(?:target opponent|each opponent) loses (\d+) life/i)))e.push({op:"LOSE_LIFE",player:"OPPONENT",amount:Number(m[1])});
  if((m=text.match(/deals (\d+) damage to (?:any target|target player|target opponent|each opponent)/i)))e.push({op:"DAMAGE",amount:Number(m[1]),target:"ANY_TARGET"});
  if(/destroy target creature/i.test(text))e.push({op:"DESTROY",target:"CREATURE"});
  else if(/destroy target permanent/i.test(text))e.push({op:"DESTROY",target:"PERMANENT"});
  if(/exile target creature/i.test(text))e.push({op:"EXILE",target:"CREATURE"});
  else if(/exile target permanent/i.test(text))e.push({op:"EXILE",target:"PERMANENT"});
  if(/destroy all creatures/i.test(text))e.push({op:"DESTROY_ALL",filter:"CREATURE"});
  if(/proliferate/i.test(text))e.push({op:"PROLIFERATE"});
  const u=/create (a|an|one|two|three|four|five|six|\d+) (Treasure|Food|Clue|Blood) tokens?/gi;
  while((m=u.exec(text)))e.push({op:"CREATE_TOKEN",token:m[2].toUpperCase(),amount:qty(m[1])});
  const ct=/create (a|an|one|two|three|four|five|six|\d+) (\d+)\/(\d+) ([^.]*?) creature tokens?(?: with ([^.]+))?/gi;
  while((m=ct.exec(text))){
    const words=m[4].trim().split(/\s+/);const subtype=(words.at(-1)||"Creature").replace(/[^A-Za-z'-]/g,"");
    e.push({op:"CREATE_CREATURE_TOKEN",amount:qty(m[1]),power:Number(m[2]),toughness:Number(m[3]),subtype,keywords:(m[5]||"").split(/,| and /).map(x=>x.trim()).filter(Boolean)});
  }
  if((m=text.match(/put (a|one|two|three|four|\d+) \+1\/\+1 counters? on target ([^.,]+)/i)))e.push({op:"ADD_COUNTER",counter:"+1/+1",amount:qty(m[1]),target:m[2].trim()});
  if(/\bexplores\b/i.test(text))e.push({op:"EXPLORE"});
  if(/search your library/i.test(text)&&/land card/i.test(text))e.push({op:"SEARCH_LIBRARY",filter:"LAND",destination:/onto the battlefield/i.test(text)?"BATTLEFIELD":"HAND",tapped:/battlefield tapped/i.test(text)});
  return e;
}
function compile(card){
  const text=card.oracleText||"", interactions=[];
  for(const k of card.keywords||[])interactions.push({kind:"KEYWORD",keyword:k});
  if(card.name==="Academy Manufactor")interactions.push({kind:"REPLACEMENT",event:"CREATE_UTILITY_TOKEN",replaceWith:["FOOD","CLUE","TREASURE"]});
  if(card.name==="Xorn")interactions.push({kind:"REPLACEMENT",event:"CREATE_TREASURE",extra:1});
  if(card.name==="Hardened Scales")interactions.push({kind:"REPLACEMENT",event:"ADD_+1/+1_COUNTER",extra:1});
  if(card.name==="Branching Evolution")interactions.push({kind:"REPLACEMENT",event:"ADD_+1/+1_COUNTER",multiplier:2});
  if(/other merfolk.*get \+1\/\+1/i.test(text)||["Master of the Pearl Trident","Merfolk Sovereign","Merfolk Mistbinder"].includes(card.name))interactions.push({kind:"STATIC_MODIFIER",filter:"OTHER_MERFOLK_YOU_CONTROL",power:1,toughness:1});
  for(const line of text.split("\n")){
    const i=line.indexOf(":");
    if(i>0)interactions.push({kind:"ACTIVATED",cost:line.slice(0,i).trim(),raw:line.slice(i+1).trim(),effects:compileEffect(line.slice(i+1))});
    const m=line.match(/^(When|Whenever|At) ([^,]+),\s*(.+)$/i);
    if(m)interactions.push({kind:"TRIGGERED",trigger:m[1].toUpperCase(),condition:m[2].trim(),raw:m[3].trim(),effects:compileEffect(m[3])});
  }
  if(["Instant","Sorcery"].includes(card.type))interactions.push({kind:"RESOLVE",effects:compileEffect(text)});
  const named={
    "Hakbal of the Surging Soul":[{kind:"TRIGGERED",event:"BEGIN_COMBAT_YOURS",effects:[{op:"EXPLORE_EACH",filter:"MERFOLK_YOU_CONTROL"}]},{kind:"TRIGGERED",event:"ATTACKS",effects:[{op:"MAY_PUT_LAND_FROM_HAND"}]}],
    "Deeproot Waters":[{kind:"TRIGGERED",event:"CAST_MERFOLK",effects:[{op:"CREATE_CREATURE_TOKEN",amount:1,power:1,toughness:1,subtype:"Merfolk",keywords:["Hexproof"]}]}],
    "Deeproot Pilgrimage":[{kind:"TRIGGERED",event:"NONTOKEN_MERFOLK_TAPPED",effects:[{op:"CREATE_CREATURE_TOKEN",amount:1,power:1,toughness:1,subtype:"Merfolk",keywords:["Hexproof"]}]}],
    "Evolution Sage":[{kind:"TRIGGERED",event:"LANDFALL",effects:[{op:"PROLIFERATE"}]}],
    "Mirkwood Bats":[{kind:"TRIGGERED",event:"TOKEN_CREATED_OR_SACRIFICED",effects:[{op:"LOSE_LIFE",player:"EACH_OPPONENT",amount:1}]}],
    "Phyrexian Arena":[{kind:"TRIGGERED",event:"UPKEEP_YOURS",effects:[{op:"DRAW",amount:1},{op:"LOSE_LIFE",player:"YOU",amount:1}]}],
    "Seafloor Oracle":[{kind:"TRIGGERED",event:"MERFOLK_COMBAT_DAMAGE_TO_PLAYER",effects:[{op:"DRAW",amount:1}]}]
  };
  if(named[card.name])interactions.push(...named[card.name]);
  if(CUSTOM_OVERRIDES[card.name]){
    card.customCategory=CUSTOM_OVERRIDES[card.name].category||null;
    card.customRulesSummary=CUSTOM_OVERRIDES[card.name].rulesSummary||"";
    for(const interaction of CUSTOM_OVERRIDES[card.name].interactions||[]){
      interactions.push({kind:"CUSTOM_SPEC",...interaction});
    }
  }
  card.interactions=interactions;return card;
}
async function build(){
  const cards=new Map(),deckRecords={};
  for(const [id,cfg] of Object.entries(DECKS)){
    let commander,list=[];
    if(cfg.list){
      const names=parseDeckList(cfg.list), lookup=await collection(uniq(names));
      commander=resolveCard(lookup,cfg.commander);
      let skip=false;
      for(const name of names){
        const c=resolveCard(lookup,name);if(!c)continue;
        cards.set(c.name,c);if(name===cfg.commander&&!skip){skip=true;continue}list.push(c.name);
      }
    }else{
      const base=await collection([cfg.commander,...(cfg.dynamic.featured||[]),...cfg.dynamic.basics.map(x=>x[0])]);
      commander=base[cfg.commander]||Object.values(base)[0];const chosen=[];
      for(const name of cfg.dynamic.featured||[]){const c=base[name];if(c&&!chosen.some(x=>x.name===c.name)){chosen.push(c);cards.set(c.name,c)}}
      for(const c of await search(cfg.dynamic.query)){if(chosen.length>=cfg.dynamic.nonlands)break;if(c.name===commander.name||chosen.some(x=>x.name===c.name))continue;chosen.push(c);cards.set(c.name,c)}
      list=chosen.map(c=>c.name);
      for(const [name,count] of cfg.dynamic.basics){const c=base[name];cards.set(c.name,c);for(let i=0;i<count;i++)list.push(c.name)}
    }
    if(!commander) throw new Error(`Commander could not be resolved for deck ${id}: ${cfg.commander}`);
    if(!commander) throw new Error(`Commander could not be resolved for deck ${id}: ${cfg.commander}`); cards.set(commander.name,commander);
    if(list.length<99){
      const filler=list.find(n=>cards.get(n)?.type==="Land")||list[0];
      if(!filler) throw new Error(`Deck ${id} has no resolvable cards.`);
      while(list.length<99) list.push(filler);
    }
    deckRecords[id]={id,name:cfg.name,subtitle:cfg.subtitle,icon:cfg.icon,commander:commander.name,cards:list.slice(0,99)};
  }
  const compiled=[...cards.values()].map(compile).sort((a,b)=>a.name.localeCompare(b.name));
  fs.writeFileSync(path.join(OUT,"cards.json"),JSON.stringify({schemaVersion:1,generatedAt:new Date().toISOString(),cardCount:compiled.length,cards:Object.fromEntries(compiled.map(c=>[c.name,c]))},null,2));
  fs.writeFileSync(path.join(OUT,"decks.json"),JSON.stringify({schemaVersion:1,decks:deckRecords},null,2));
  console.log(`Built database with ${compiled.length} unique cards.`);
}
build().catch(e=>{console.error(e);process.exit(1)});
