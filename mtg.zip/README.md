# MTG AI Trainer v3

A clean React/Vite Commander practice simulator built around a standalone game engine. The UI never mutates Magic state directly; player and AI actions both go through the same legal-action and rules pipeline.

## Included systems

1. Canonical game state/zones
2. Deck initialization, shuffle, opening hands, London-style mulligan bottoming
3. Full turn/phase sequence
4. Lands and mana pools
5. Casting and LIFO stack
6. Permanents and summoning sickness
7. Combat and blockers
8. State-based lethal/death handling
9. Counters and tokens
10. Data-driven effect engine
11. Triggered abilities/event bus
12. Replacement and static effects
13. Commander zone, tax, 21 commander damage
14. AI using legal actions
15. React battlefield UI
16. Scryfall artwork resolution + hover preview
17. Explorers of the Deep integration with Merfolk/explore/counters/proliferate
18. Six selectable decks
19. Extra combat mechanics: first strike, double strike, menace, indestructible, haste hooks
20. Heuristic AI sequencing/combat

## Run

```bash
npm install
npm test
npm run dev
```

## Verification

`npm test` runs deterministic engine, combat, synergy and AI tests plus a 100-game randomized stress suite.

## Scope

This is a training simulator implementing the mechanics represented by its structured card database, not a complete implementation of every rule/card ever printed in Magic. Add a card by adding a database record with machine-readable abilities/effects and referencing it from a deck JSON.
