import { hasSubtype } from './utils.js';
export class StaticEngine{
 constructor(engine){this.engine=engine;}
 derivedStats(perm){const d=this.engine.db[perm.cardId];let power=Number(d.power||0)+(perm.counters['+1/+1']||0)-(perm.counters['-1/-1']||0)+(perm.modifiers.power||0);let toughness=Number(d.toughness||0)+(perm.counters['+1/+1']||0)-(perm.counters['-1/-1']||0)+(perm.modifiers.toughness||0);const keywords=new Set([...(d.keywords||[]),...(perm.modifiers.keywords||[])]);for(const q of this.engine.state.players[perm.controller].battlefield){for(const a of this.engine.db[q.cardId]?.abilities||[]){if(a.type!=='static')continue; if(a.filter?.subtype&&!hasSubtype(d,a.filter.subtype))continue;if(a.effect?.power)power+=a.effect.power;if(a.effect?.toughness)toughness+=a.effect.toughness;if(a.effect?.keyword)keywords.add(a.effect.keyword);}}return {power,toughness,keywords:[...keywords]};}
}
