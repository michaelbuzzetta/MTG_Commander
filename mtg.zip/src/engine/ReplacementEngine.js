export class ReplacementEngine{
 static modifyCounterAmount(state,db,playerId,permanent,counterType,amount){let n=amount;for(const p of state.players[playerId].battlefield){const d=db[p.cardId];for(const a of d?.abilities||[]){if(a.type==='replacement'&&a.event==='COUNTERS_ADDED'&&(!a.counterType||a.counterType===counterType)){if(a.effect==='addOne')n+=1;if(a.effect==='double')n*=2;}}}return n;}
 static modifyTokenAmount(state,db,playerId,tokenType,amount){let n=amount;for(const p of state.players[playerId].battlefield){const d=db[p.cardId];for(const a of d?.abilities||[]){if(a.type==='replacement'&&a.event==='TOKEN_CREATED'){if(a.effect==='double')n*=2;if(a.effect==='manufactor'&&['Treasure','Food','Clue'].includes(tokenType))return {manufactor:n};}}}return n;}
}
