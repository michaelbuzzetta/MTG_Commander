import { isType } from './utils.js';
export class LegalActions{
 constructor(engine){this.engine=engine;}
 get(pid){const e=this.engine,s=e.state,p=s.players[pid],out=[];if(s.winner||s.priorityPlayer!==pid)return out;
  if(['PRECOMBAT_MAIN','POSTCOMBAT_MAIN'].includes(s.phase)&&pid===s.activePlayer&&p.landPlaysRemaining>0){for(const c of p.hand)if(isType(e.db[c.cardId],'Land'))out.push({type:'PLAY_LAND',cardInstanceId:c.instanceId});}
  for(const c of p.hand){const d=e.db[c.cardId];if(isType(d,'Land'))continue;const instant=isType(d,'Instant')||(d.keywords||[]).includes('Flash');const timing=instant||(['PRECOMBAT_MAIN','POSTCOMBAT_MAIN'].includes(s.phase)&&pid===s.activePlayer&&s.stack.length===0);if(timing&&e.canCast(pid,c))out.push({type:'CAST_SPELL',cardInstanceId:c.instanceId});}
  for(const c of p.command){if(c.isCommander&&e.canCast(pid,c))out.push({type:'CAST_COMMANDER',cardInstanceId:c.instanceId});}
  for(const perm of p.battlefield){const d=e.db[perm.cardId];for(const a of d.abilities||[]){if(a.type==='mana'&&!perm.tapped)out.push({type:'ACTIVATE_MANA',permanentId:perm.instanceId,ability:a});if(a.type==='activated'&&(!a.tap||!perm.tapped))out.push({type:'ACTIVATE_ABILITY',permanentId:perm.instanceId,ability:a});}}
  if(s.phase==='DECLARE_ATTACKERS'&&pid===s.activePlayer)out.push({type:'DECLARE_ATTACKERS'});if(s.phase==='DECLARE_BLOCKERS'&&pid!==s.activePlayer)out.push({type:'DECLARE_BLOCKERS'});out.push({type:'PASS_PRIORITY'});return out;}
}
