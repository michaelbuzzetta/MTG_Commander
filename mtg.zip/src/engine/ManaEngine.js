const xAmount = ability => Object.values(ability.mana || {}).reduce((a,b)=>a+b,0);
import { parseManaCost, isType } from './utils.js';

export class ManaEngine {
  static canPay(player, cost, tax = 0) {
    const r = parseManaCost(cost); r.generic += tax;
    const pool = { ...player.manaPool };
    for (const c of ['W','U','B','R','G','C']) {
      if ((pool[c] || 0) < r[c]) return false;
      pool[c] -= r[c];
    }
    return Object.values(pool).reduce((a,b)=>a+b,0) >= r.generic;
  }

  static pay(player, cost, tax = 0) {
    if (!this.canPay(player, cost, tax)) return false;
    const r = parseManaCost(cost); r.generic += tax;
    for (const c of ['W','U','B','R','G','C']) player.manaPool[c] -= r[c];
    for (const c of ['C','W','U','B','R','G']) {
      const n = Math.min(player.manaPool[c], r.generic);
      player.manaPool[c] -= n; r.generic -= n;
    }
    return true;
  }

  static clear(player) { for (const c of Object.keys(player.manaPool)) player.manaPool[c] = 0; }
  static add(player, mana) { for (const [c,n] of Object.entries(mana)) player.manaPool[c] = (player.manaPool[c] || 0) + n; }

  static manaAbilities(player, db) {
    const sources = [];
    for (const perm of player.battlefield) {
      if (perm.tapped) continue;
      const def = db[perm.cardId];
      for (const ability of def?.abilities || []) {
        if (ability.type !== 'mana') continue;
        
        if (ability.anyColor) {
          for (const c of (player.colorIdentity?.length ? player.colorIdentity : ['W','U','B','R','G'])) {
            sources.push({ permanent: perm, ability: { ...ability, mana: { [c]: ability.amount || 1 } } });
          }
        } else {
          sources.push({ permanent: perm, ability });
        }
      }
    }
    return sources;
  }

  static canAfford(player, db, cost, tax = 0) {
    const req = parseManaCost(cost); req.generic += tax;
    const pool = { ...player.manaPool };
    const sources = this.manaAbilities(player, db);
    const used = new Set();
    for (const c of ['W','U','B','R','G','C']) {
      const fromPool = Math.min(pool[c] || 0, req[c]);
      pool[c] -= fromPool; req[c] -= fromPool;
      while (req[c] > 0) {
        const src = sources.find(x => !used.has(x.permanent.instanceId) && (x.ability.mana?.[c] || 0) > 0);
        if (!src) return false;
        used.add(src.permanent.instanceId);
        req[c] -= Math.min(req[c], xAmount(src.ability));
      }
    }
    let genericPool = Object.values(pool).reduce((a,b)=>a+b,0);
    let generic = Math.max(0, req.generic - genericPool);
    const uniqueUnused = [];
    const seen = new Set();
    for (const src of sources) if (!used.has(src.permanent.instanceId) && !seen.has(src.permanent.instanceId)) { seen.add(src.permanent.instanceId); uniqueUnused.push(src); }
    uniqueUnused.sort((a,b)=>xAmount(b.ability)-xAmount(a.ability));
    for (const src of uniqueUnused) { if (generic<=0) break; generic -= xAmount(src.ability); }
    return generic <= 0;
  }

  // Arena-like auto-tap. Colored requirements are satisfied first, then generic.
  static autoTapAndPay(player, db, cost, tax = 0) {
    const req = parseManaCost(cost); req.generic += tax;
    if (!this.canAfford(player, db, cost, tax)) return false;

    // Spend any floating mana first for exact colored symbols.
    const remaining = { ...req };
    for (const c of ['W','U','B','R','G','C']) {
      const n = Math.min(player.manaPool[c] || 0, remaining[c]);
      player.manaPool[c] -= n; remaining[c] -= n;
    }

    const sources = this.manaAbilities(player, db);
    const used = new Set();

    // Tap sources that actually make a required colored mana symbol.
    for (const c of ['W','U','B','R','G','C']) {
      while (remaining[c] > 0) {
        const src = sources.find(x => !used.has(x.permanent.instanceId) && (x.ability.mana?.[c] || 0) > 0);
        if (!src) return false;
        used.add(src.permanent.instanceId);
        src.permanent.tapped = true;
        this.add(player, src.ability.mana);
        const n = Math.min(player.manaPool[c] || 0, remaining[c]);
        player.manaPool[c] -= n; remaining[c] -= n;
      }
    }

    // Any extra floating mana can satisfy generic.
    let generic = remaining.generic;
    for (const c of ['C','W','U','B','R','G']) {
      const n = Math.min(player.manaPool[c] || 0, generic);
      player.manaPool[c] -= n; generic -= n;
    }

    // Tap the fewest remaining sources needed for generic mana.
    const remainingSources = sources
      .filter(x => !used.has(x.permanent.instanceId))
      .sort((a,b) => Object.values(b.ability.mana || {}).reduce((n,x)=>n+x,0) - Object.values(a.ability.mana || {}).reduce((n,x)=>n+x,0));
    for (const src of remainingSources) {
      if (generic <= 0) break;
      used.add(src.permanent.instanceId);
      src.permanent.tapped = true;
      this.add(player, src.ability.mana);
      for (const c of ['C','W','U','B','R','G']) {
        const n = Math.min(player.manaPool[c] || 0, generic);
        player.manaPool[c] -= n; generic -= n;
      }
    }
    return generic === 0;
  }
}
