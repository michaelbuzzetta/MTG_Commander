import {computedPT,isMerfolk} from "./RulesEngine";

const other=s=>s==="you"?"ai":"you";
const N={a:1,an:1,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
const n=(x,d=1)=>(N[String(x||"").toLowerCase()] ?? Number(x) ?? d);
const log=(s,m)=>{s.log.unshift(m);s.log=s.log.slice(0,80)};

export function draw(s,side,count=1){
  const p=s.players[side];
  for(let i=0;i<count;i++){
    if(!p.library.length){p.lost=true;break}
    const c=p.library.shift();c.zone="hand";p.hand.push(c);
  }
}
export const gainLife=(s,side,x)=>s.players[side].life+=Math.max(0,x);
export const loseLife=(s,side,x)=>s.players[side].life-=Math.max(0,x);

function counterAmount(s,side,type,count){
  if(type!=="+1/+1") return count;
  const bf=s.players[side].battlefield;
  let out=count;
  if(bf.some(c=>c.name==="Hardened Scales")) out+=1;
  for(const _ of bf.filter(c=>c.name==="Branching Evolution")) out*=2;
  return out;
}
export function addCounter(card,type="+1/+1",count=1,s=null,side=null){
  const amount=s&&side?counterAmount(s,side,type,count):count;
  card.counters ||= {};
  card.counters[type]=(card.counters[type]||0)+amount;
  if(s&&side&&type==="+1/+1"){
    const a=s.players[side].battlefield.find(c=>c.name==="Simic Ascendancy");
    if(a&&a.id!==card.id){
      a.counters ||= {}; a.counters.growth=(a.counters.growth||0)+amount;
      log(s,`Simic Ascendancy gained ${amount} growth counter${amount===1?"":"s"}.`);
    }
  }
  return amount;
}

const utilSpec=name=>({
  name,typeLine:`Token Artifact — ${name}`,power:0,toughness:0,keywords:[]
});
const creatureSpec=(name,subtype,p,t,keywords=[])=>({
  name,typeLine:`Token Creature — ${subtype}`,power:p,toughness:t,keywords
});

function makeToken(side,spec){
  return {
    id:`tok-${Date.now()}-${Math.random()}`,owner:side,controller:side,zone:"battlefield",
    name:spec.name,cardType:spec.typeLine.includes("Creature")?"Creature":"Artifact",
    typeLine:spec.typeLine,oracleText:"Token",manaCost:"",manaValue:0,colors:[],colorIdentity:[],
    keywords:spec.keywords||[],power:spec.power||0,toughness:spec.toughness||0,image:"",
    producedMana:spec.name==="Treasure"?["W","U","B","R","G"]:[],
    tapped:false,summoningSick:spec.typeLine.includes("Creature"),
    counters:{"+1/+1":0,"-1/-1":0},damage:0,token:true,revealed:true
  };
}

function replacementPlans(s,side,spec,count){
  const bf=s.players[side].battlefield;
  if(["Food","Clue","Treasure"].includes(spec.name)&&bf.some(c=>c.name==="Academy Manufactor")){
    return ["Food","Clue","Treasure"].map(name=>({spec:utilSpec(name),count}));
  }
  if(spec.name==="Treasure"&&bf.some(c=>c.name==="Xorn")) count++;
  return [{spec,count}];
}

export function createTokens(s,side,spec,count=1,{skipReplacement=false}={}){
  const plans=skipReplacement?[{spec,count}]:replacementPlans(s,side,spec,count);
  const made=[];
  for(const plan of plans){
    for(let i=0;i<plan.count;i++){
      const token=makeToken(side,plan.spec);
      s.players[side].battlefield.push(token);made.push(token);
      triggerEvent(s,{type:"TOKEN_CREATED",side,card:token});
      triggerEvent(s,{type:"PERMANENT_ENTERED",side,card:token});
    }
  }
  if(made.length) log(s,`${side==="you"?"You":"AI"} created ${made.map(c=>c.name).join(", ")}.`);
  return made;
}
export function createToken(s,side,name,typeLine,p=0,t=0,keywords=[]){
  return createTokens(s,side,{name,typeLine,power:p,toughness:t,keywords},1)[0];
}
export function sacrificeToken(s,side,card){
  const p=s.players[side],i=p.battlefield.findIndex(c=>c.id===card.id);
  if(i<0)return false;
  const [gone]=p.battlefield.splice(i,1);
  triggerEvent(s,{type:"TOKEN_SACRIFICED",side,card:gone});
  return true;
}
export function destroyPermanent(s,card){
  const p=s.players[card.owner],i=p.battlefield.findIndex(c=>c.id===card.id);
  if(i<0)return;
  const [dead]=p.battlefield.splice(i,1);
  if(!dead.token){dead.zone="graveyard";p.graveyard.push(dead)}
  triggerEvent(s,{type:"DIED",side:card.controller,card:dead});
}

export function explore(s,side,creature){
  const p=s.players[side]; if(!p.library.length)return;
  const top=p.library.shift();top.revealed=true;
  if(top.cardType==="Land"){
    top.zone="hand";p.hand.push(top);log(s,`${creature.name} explored: ${top.name} to hand.`);
  }else{
    const amount=addCounter(creature,"+1/+1",1,s,side);
    top.zone="graveyard";p.graveyard.push(top);
    log(s,`${creature.name} explored: +${amount}/+${amount}; ${top.name} to graveyard.`);
  }
}

function strongest(s,side){
  const p=s.players[side];
  return [...p.battlefield.filter(c=>c.cardType==="Creature")]
    .sort((a,b)=>computedPT(b,p.battlefield).power-computedPT(a,p.battlefield).power)[0];
}
function parseCreates(text){
  const out=[];let m;
  const utility=/create (a|an|one|two|three|four|five|six|\d+) (Treasure|Food|Clue|Blood) tokens?/gi;
  while((m=utility.exec(text))) out.push({count:n(m[1]),spec:utilSpec(m[2])});
  const creature=/create (a|an|one|two|three|four|five|six|\d+) (\d+)\/(\d+) ([^.]*?) creature tokens?(?: with ([^.]+))?/gi;
  while((m=creature.exec(text))){
    const descriptor=m[4].trim().split(/\s+/);
    const subtype=(descriptor.at(-1)||"Creature").replace(/[^A-Za-z'-]/g,"");
    const kws=(m[5]||"").split(/,| and /).map(x=>x.trim()).filter(Boolean);
    out.push({count:n(m[1]),spec:creatureSpec(`${subtype} Token`,subtype,Number(m[2]),Number(m[3]),kws)});
  }
  return out;
}

export function proliferate(s,side){
  let changed=0;
  for(const c of s.players[side].battlefield){
    for(const [type,count] of Object.entries(c.counters||{})){
      if(count>0){c.counters[type]=count+1;changed++}
    }
  }
  if(changed)log(s,`Proliferated counters on ${changed} permanent${changed===1?"":"s"}.`);
}

export function resolveOracle(s,side,source){
  const p=s.players[side],oppSide=other(side);
  const text=source.oracleText||"",lower=text.toLowerCase();
  const oneShot=text.split("\n").filter(x=>! /^(when|whenever|at the beginning)/i.test(x)).join("\n");
  let m;

  if(/\bdraw (?:a|one) card\b/i.test(oneShot))draw(s,side,1);
  if((m=oneShot.match(/\bdraw (\d+) cards?/i)))draw(s,side,Number(m[1]));
  if((m=oneShot.match(/\byou gain (\d+) life/i)))gainLife(s,side,Number(m[1]));
  if((m=oneShot.match(/(?:target opponent|each opponent) loses (\d+) life/i)))loseLife(s,oppSide,Number(m[1]));
  if((m=oneShot.match(/deals (\d+) damage to (?:any target|target player|target opponent|each opponent)/i)))loseLife(s,oppSide,Number(m[1]));

  for(const c of parseCreates(oneShot))createTokens(s,side,c.spec,c.count);

  if(/destroy target (?:creature|permanent)/i.test(oneShot)||/exile target (?:creature|permanent)/i.test(oneShot)){
    const t=strongest(s,oppSide);if(t)destroyPermanent(s,t);
  }
  if(/destroy all creatures/i.test(oneShot)){
    for(const c of [...s.players.you.battlefield,...s.players.ai.battlefield].filter(c=>c.cardType==="Creature"))destroyPermanent(s,c);
  }

  if(lower.includes("search your library")&&lower.includes("land card")){
    const count=/up to two|two .* land cards/i.test(lower)?2:1;
    for(let k=0;k<count;k++){
      const i=p.library.findIndex(c=>c.cardType==="Land");
      if(i>=0){
        const land=p.library.splice(i,1)[0];land.zone="battlefield";land.tapped=true;p.battlefield.push(land);
        log(s,`${source.name} found ${land.name} tapped.`);
        triggerEvent(s,{type:"PERMANENT_ENTERED",side,card:land});
      }
    }
  }

  if((m=oneShot.match(/put (a|one|two|three|\d+) \+1\/\+1 counters? on target creature you control/i))){
    const t=strongest(s,side);if(t)addCounter(t,"+1/+1",n(m[1]),s,side);
  }
  if(lower.includes("proliferate"))proliferate(s,side);
  if(lower.includes("target creature")&&lower.includes("explores")){
    const t=strongest(s,side);if(t)explore(s,side,t);
  }
}

function tokenDrain(s,side){
  const opp=s.players[other(side)];
  for(const c of s.players[side].battlefield){
    if(c.name==="Mirkwood Bats"){opp.life--;log(s,"Mirkwood Bats: opponent lost 1 life.");}
    if(c.name==="Nadier's Nightblade"){opp.life--;log(s,"Nadier's Nightblade: opponent lost 1 life.");}
  }
}

export function triggerEvent(s,e){
  const p=s.players[e.side],opp=s.players[other(e.side)];

  if(e.type==="CAST_SPELL"){
    const spell=e.card;
    for(const src of [...p.battlefield]){
      if(src.name==="Deeproot Waters"&&isMerfolk(spell))
        createTokens(s,e.side,creatureSpec("Merfolk Token","Merfolk",1,1,["Hexproof"]),1);
      if(src.name==="Vanquisher's Banner"&&isMerfolk(spell)){draw(s,e.side,1);log(s,"Vanquisher's Banner drew a card.");}
      const t=(src.oracleText||"").toLowerCase();
      if(t.includes("whenever you cast")&&t.includes("create a treasure"))createTokens(s,e.side,utilSpec("Treasure"),1);
    }
  }

  if(e.type==="PERMANENT_ENTERED"){
    const entered=e.card;
    if(entered.cardType==="Land"&&p.battlefield.some(c=>c.name==="Evolution Sage"))proliferate(s,e.side);

    for(const src of [...p.battlefield]){
      const t=(src.oracleText||"").toLowerCase();
      if(src.id!==entered.id&&entered.cardType==="Creature"&&t.includes("whenever another")&&t.includes("enters")&&t.includes("+1/+1 counter")){
        if(!t.includes("merfolk")||isMerfolk(entered)){
          const amount=addCounter(src,"+1/+1",1,s,e.side);log(s,`${src.name} received ${amount} +1/+1 counter${amount===1?"":"s"}.`);
        }
      }
      if(src.name==="Kindred Discovery"&&entered.cardType==="Creature"&&isMerfolk(entered)){draw(s,e.side,1);log(s,"Kindred Discovery drew a card.");}
      if(src.id!==entered.id&&entered.cardType==="Artifact"&&t.includes("whenever an artifact")&&t.includes("enters")&&t.includes("deals 1 damage")){
        opp.life--;log(s,`${src.name} dealt 1 damage.`);
      }
      if(src.id===entered.id&&/^when .* enters/im.test(src.oracleText||"")){
        const txt=src.oracleText||"";
        if(/draw a card/i.test(txt)){draw(s,e.side,1);log(s,`${src.name} drew a card on entry.`)}
        const life=txt.match(/you gain (\d+) life/i);if(life)gainLife(s,e.side,Number(life[1]));
        for(const c of parseCreates(txt))createTokens(s,e.side,c.spec,c.count);
      }
    }
  }

  if(e.type==="TOKEN_CREATED"){
    tokenDrain(s,e.side);
    if(e.card.cardType==="Artifact"){
      for(const src of p.battlefield){
        if(src.name==="Reckless Fireweaver"){opp.life--;log(s,"Reckless Fireweaver dealt 1 damage.");}
        if(src.name==="Ingenious Artillerist"){opp.life--;log(s,"Ingenious Artillerist dealt 1 damage.");}
      }
    }
  }
  if(e.type==="TOKEN_SACRIFICED")tokenDrain(s,e.side);

  if(e.type==="MERFOLK_TAPPED"&&e.cards?.some(c=>isMerfolk(c)&&!c.token)){
    if(p.battlefield.some(c=>c.name==="Deeproot Pilgrimage")){
      createTokens(s,e.side,creatureSpec("Merfolk Token","Merfolk",1,1,["Hexproof"]),1);
      log(s,"Deeproot Pilgrimage created a 1/1 hexproof Merfolk.");
    }
  }

  if(e.type==="BEGIN_COMBAT"){
    if(p.battlefield.some(c=>c.name==="Hakbal of the Surging Soul")){
      const merfolk=p.battlefield.filter(isMerfolk);
      merfolk.forEach(c=>explore(s,e.side,c));
      log(s,`Hakbal: ${merfolk.length} Merfolk explored.`);
    }
  }

  if(e.type==="CREATURE_ATTACKED"){
    const a=e.card;
    if(isMerfolk(a)&&p.battlefield.some(c=>c.name==="Kindred Discovery")){draw(s,e.side,1);log(s,"Kindred Discovery drew a card for attacking.");}
    if(a.name==="Hakbal of the Surging Soul"){
      const i=p.hand.findIndex(c=>c.cardType==="Land");
      if(i>=0){
        const land=p.hand.splice(i,1)[0];land.zone="battlefield";land.tapped=false;p.battlefield.push(land);
        log(s,`Hakbal put ${land.name} from hand onto the battlefield.`);
        triggerEvent(s,{type:"PERMANENT_ENTERED",side:e.side,card:land});
      }
    }
  }

  if(e.type==="COMBAT_DAMAGE_TO_PLAYER"){
    const c=e.card;
    if(isMerfolk(c)&&p.battlefield.some(x=>x.name==="Seafloor Oracle")){draw(s,e.side,1);log(s,"Seafloor Oracle drew a card.");}
    if(c.name==="Goldspan Dragon")createTokens(s,e.side,utilSpec("Treasure"),1);
  }

  if(e.type==="DIED"){
    for(const src of [...p.battlefield]){
      const t=(src.oracleText||"").toLowerCase();
      if(t.includes("whenever")&&t.includes("dies")){
        if(t.includes("draw a card"))draw(s,e.side,1);
        if(t.includes("create a treasure"))createTokens(s,e.side,utilSpec("Treasure"),1);
        if(t.includes("loses 1 life"))opp.life--;
      }
      if(src.name==="Morbid Opportunist"&&e.card.cardType==="Creature"){draw(s,e.side,1);log(s,"Morbid Opportunist drew a card.");}
    }
  }

  if(e.type==="UPKEEP"){
    const a=p.battlefield.find(c=>c.name==="Simic Ascendancy");
    if(a&&(a.counters?.growth||0)>=20){s.winner=e.side;log(s,"Simic Ascendancy: 20 growth counters — win!");}
    if(p.battlefield.some(c=>c.name==="Phyrexian Arena")){draw(s,e.side,1);p.life--;log(s,"Phyrexian Arena drew a card; lost 1 life.");}
  }

  if(e.type==="END_STEP"){
    if(p.battlefield.some(c=>c.name==="Mahadi, Emporium Master")){
      const deaths=s.turnStats?.creaturesDied||0;
      if(deaths)createTokens(s,e.side,utilSpec("Treasure"),deaths);
    }
  }
}

export function activateUtilityToken(s,side,id){
  const p=s.players[side],card=p.battlefield.find(c=>c.id===id);
  if(!card?.token)return false;
  if(card.name==="Food"){sacrificeToken(s,side,card);gainLife(s,side,3);log(s,"Food sacrificed: gained 3 life.");return true}
  if(card.name==="Clue"){sacrificeToken(s,side,card);draw(s,side,1);log(s,"Clue sacrificed: drew a card.");return true}
  if(card.name==="Blood"&&p.hand.length){
    const d=p.hand.shift();d.zone="graveyard";p.graveyard.push(d);
    sacrificeToken(s,side,card);draw(s,side,1);log(s,"Blood activated: discarded, then drew.");return true
  }
  return false;
}
export function activateNamedPermanent(s,side,id){
  const p=s.players[side],card=p.battlefield.find(c=>c.id===id);
  if(card?.name!=="Simic Ascendancy")return false;
  const target=strongest(s,side);if(!target)return false;
  const amount=addCounter(target,"+1/+1",1,s,side);
  log(s,`Simic Ascendancy put ${amount} +1/+1 counter${amount===1?"":"s"} on ${target.name}.`);
  return true;
}
