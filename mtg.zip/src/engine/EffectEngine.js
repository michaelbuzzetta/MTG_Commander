import { makeCardInstance } from './GameState.js';
import { ReplacementEngine } from './ReplacementEngine.js';
import { EVENT } from './constants.js';
import { isType, hasSubtype } from './utils.js';
export class EffectEngine{
 constructor(engine){this.engine=engine;}
 resolve(effect,ctx={}){if(!effect)return; const e=this.engine,s=e.state,pid=effect.player||ctx.controller||s.activePlayer,p=s.players[pid];
  switch(effect.type){
   case 'draw': for(let i=0;i<(effect.amount||1);i++)e.draw(pid); break;
   case 'gainLife': e.changeLife(pid,effect.amount||1); break;
   case 'loseLife': e.changeLife(pid,-(effect.amount||1)); break;
   case 'damagePlayer': e.dealDamageToPlayer(effect.targetPlayer||e.opponent(pid),effect.amount||1,ctx.source); break;
   case 'addMana': this.engine.mana.add(p,effect.mana||{}); break;
   case 'createToken': this.createToken(pid,effect.token,effect.amount||1); break;
   case 'addCounter': {const targets=e.selectPermanents(pid,effect.filter||{},ctx);for(const t of targets.slice(0,effect.maxTargets||targets.length))this.addCounters(pid,t,effect.counter||'+1/+1',effect.amount||1);}break;
   case 'pump': {for(const t of e.selectPermanents(pid,effect.filter||{},ctx)){t.modifiers.power+=(effect.power||0);t.modifiers.toughness+=(effect.toughness||0); if(effect.keyword&&!t.modifiers.keywords.includes(effect.keyword))t.modifiers.keywords.push(effect.keyword);}}break;
   case 'destroy': {for(const t of e.selectPermanents(effect.targetPlayer||e.opponent(pid),effect.filter||{},ctx).slice(0,effect.maxTargets||1))e.destroy(t);}break;
   case 'exile': {for(const t of e.selectPermanents(effect.targetPlayer||e.opponent(pid),effect.filter||{},ctx).slice(0,effect.maxTargets||1))e.exile(t);}break;
   case 'proliferate': for(const pp of Object.values(s.players))for(const t of pp.battlefield)for(const k of Object.keys(t.counters||{}))if(t.counters[k]>0)this.addCounters(t.controller,t,k,1); break;
   case 'explore': this.explore(effect.target||ctx.target||e.selectPermanents(pid,{type:'Creature'},ctx)[0]); break;
   case 'exploreAll': for(const t of e.selectPermanents(pid,effect.filter||{type:'Creature'},ctx))this.explore(t); break;
   case 'searchBasic': {const i=p.library.findIndex(c=>isType(e.db[c.cardId],'Basic Land')); if(i>=0){const [c]=p.library.splice(i,1);c.zone=effect.destination||'hand';p[c.zone].push(c);}}break;
   case 'sacrifice': {const t=e.selectPermanents(pid,effect.filter||{},ctx)[0];if(t)e.sacrifice(t);}break;
  }
 }
 addCounters(pid,permanent,type,amount){const n=ReplacementEngine.modifyCounterAmount(this.engine.state,this.engine.db,pid,permanent,type,amount);permanent.counters[type]=(permanent.counters[type]||0)+n;this.engine.emit(EVENT.COUNTERS_ADDED,{controller:pid,target:permanent,counterType:type,amount:n});}
 createToken(pid,token,amount){const mod=ReplacementEngine.modifyTokenAmount(this.engine.state,this.engine.db,pid,token.name||token.type,amount);if(typeof mod==='object'&&mod.manufactor){for(const t of ['Treasure','Food','Clue'])this.createTokenRaw(pid,{name:t,typeLine:`Artifact — ${t}`,colors:[],abilities:[]},mod.manufactor);return;}for(let i=0;i<mod;i++)this.createTokenRaw(pid,token,1);}
 createTokenRaw(pid,token){const id=`token:${token.name}`;if(!this.engine.db[id])this.engine.db[id]={id,name:token.name,typeLine:token.typeLine||'Token Creature',power:token.power??0,toughness:token.toughness??0,keywords:token.keywords||[],subtypes:token.subtypes||[],abilities:token.abilities||[]};const c=makeCardInstance(id,pid,'battlefield',{controller:pid,isToken:true,summoningSick:isType(this.engine.db[id],'Creature'),createdTurn:this.engine.state.turn});this.engine.state.players[pid].battlefield.push(c);this.engine.emit(EVENT.TOKEN_CREATED,{controller:pid,target:c});this.engine.emit(EVENT.ENTER_BATTLEFIELD,{controller:pid,target:c});}
 explore(target){if(!target)return;const p=this.engine.state.players[target.controller],top=p.library.shift();if(!top)return;const d=this.engine.db[top.cardId];if(isType(d,'Land')){top.zone='hand';p.hand.push(top);}else{this.addCounters(target.controller,target,'+1/+1',1);top.zone='graveyard';p.graveyard.push(top);}}
}
