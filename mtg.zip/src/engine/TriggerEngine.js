export class TriggerEngine{
 constructor(engine){this.engine=engine;}
 collect(event,payload){const s=this.engine.state;for(const [pid,p] of Object.entries(s.players)){for(const perm of p.battlefield){const d=this.engine.db[perm.cardId];for(const a of d?.abilities||[]){if(a.type!=='triggered'||a.event!==event)continue;if(!this.matches(a,payload,pid,perm))continue;s.pendingTriggers.push({id:`trg-${Math.random()}`,source:perm,controller:pid,effect:a.effect,optional:!!a.optional});}}}this.flush();}
 matches(a,payload,pid,source){const c=a.condition||{};if(c.controllerEvent&&payload.controller!==pid)return false;if(c.sourceSubtype){const d=this.engine.db[payload.target?.cardId];if(!(d?.subtypes||[]).includes(c.sourceSubtype))return false;}if(c.spellSubtype){const d=this.engine.db[payload.card?.cardId];if(!(d?.subtypes||[]).includes(c.spellSubtype))return false;}if(c.notToken&&payload.target?.isToken)return false;return true;}
 flush(){const s=this.engine.state;while(s.pendingTriggers.length){const t=s.pendingTriggers.shift();s.stack.push({id:t.id,type:'trigger',controller:t.controller,source:t.source,effect:t.effect});}}
}
