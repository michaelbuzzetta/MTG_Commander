let cache=null;
export async function loadCardDatabase(){
  if(cache)return cache;
  try{
    const [a,b]=await Promise.all([fetch("/data/cards.json",{cache:"no-store"}),fetch("/data/decks.json",{cache:"no-store"})]);
    if(!a.ok||!b.ok)return {cards:{},decks:{}};
    const ca=await a.json(),de=await b.json();
    cache={schemaVersion:ca.schemaVersion||1,cards:ca.cards||{},decks:de.decks||{}};
    return cache;
  }catch{
    return {cards:{},decks:{}};
  }
}
export function resetDatabaseCache(){cache=null}
