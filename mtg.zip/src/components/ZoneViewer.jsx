
import React from "react";
import Card from "./Card";
export default function ZoneViewer({title,cards,onClose,hover}){
  return <div className="modal-backdrop" onClick={onClose}>
    <div className="zone-modal" onClick={e=>e.stopPropagation()}>
      <header><h2>{title}</h2><button onClick={onClose}>×</button></header>
      <div className="zone-grid">
        {cards.map(c=><Card key={c.id} card={c} onHover={hover.show} onMove={hover.move} onLeave={hover.hide}/>)}
      </div>
    </div>
  </div>
}
