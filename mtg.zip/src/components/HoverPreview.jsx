
import React,{useEffect,useState} from "react";
import {resolveCardImage} from "../cards/ImageResolver";
export default function HoverPreview({card,pos}){
  const [resolvedImage,setResolvedImage]=useState("");

  useEffect(()=>{
    let alive=true;
    setResolvedImage(card?.image||"");
    if(card && !card.image){
      resolveCardImage(card).then(img=>{if(alive)setResolvedImage(img||"")});
    }
    return()=>{alive=false};
  },[card?.name,card?.image]);

  if(!card) return null;
  const width=330,height=460,gap=18;
  let left=pos.x+gap,top=pos.y+gap;
  if(left+width>window.innerWidth-10) left=pos.x-width-gap;
  if(top+height>window.innerHeight-10) top=window.innerHeight-height-10;
  if(top<10)top=10;
  return <div className="hover-preview" style={{left,top}}>
    {resolvedImage?<img src={resolvedImage} alt={card.name}/>:<div className="hover-fallback"><h3>{card.name}</h3><p>{card.oracleText}</p></div>}
    <div className="hover-meta">
      <b>{card.name}</b>
      <small>{card.typeLine}</small>
      <p>{card.oracleText}</p>
    </div>
  </div>
}
