
import React from "react";
import {STEPS} from "../engine/GameEngine";

const labels={
  UNTAP:"Untap",UPKEEP:"Upkeep",DRAW:"Draw",MAIN_1:"Main 1",
  BEGIN_COMBAT:"Begin Combat",DECLARE_ATTACKERS:"Attackers",DECLARE_BLOCKERS:"Blockers",
  COMBAT_DAMAGE:"Damage",END_COMBAT:"End Combat",MAIN_2:"Main 2",END:"End",CLEANUP:"Cleanup"
};

export default function PhaseBar({state,onAdvance}){
  return <div className="phase-bar">
    <div className="phase-title">{state.activePlayer==="you"?"YOUR":"AI"} TURN</div>
    {STEPS.map(s=><button key={s} className={"phase-step "+(state.step===s?"active":"")} onClick={()=>state.activePlayer==="you"&&onAdvance?.()} disabled={state.step!==s||state.activePlayer!=="you"}>
      <span></span>{labels[s]}
    </button>)}
  </div>
}
