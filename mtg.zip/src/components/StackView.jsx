
import React from "react";
export default function StackView({stack}){
  if(!stack.length)return null;
  return <div className="stack-view">
    <label>STACK</label>
    {stack.slice().reverse().map((x,i)=><div key={x.id} className="stack-item">
      <b>{x.card.name}</b><small>{x.side==="you"?"You":"AI"}</small>
    </div>)}
  </div>
}
