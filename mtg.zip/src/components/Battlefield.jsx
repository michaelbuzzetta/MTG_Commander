import React from 'react';
import {Card} from './Card.jsx';

function kind(def={}){
 const t=(def.typeLine||'').toLowerCase();
 if(t.includes('land'))return'land';
 if(t.includes('creature'))return'creature';
 return'other';
}
export function Battlefield({player,db,onCard,selected=()=>false}){
 const groups={creature:[],other:[],land:[]};
 player.battlefield.forEach(p=>groups[kind(db[p.cardId])].push(p));
 const row=(name,items,cls)=><div className={`permanent-row ${cls}`}>
   <span className="row-label">{name}</span>
   <div className="permanent-cards">{items.map(p=><Card key={p.instanceId} perm={p} def={db[p.cardId]} selected={selected(p.instanceId)} onClick={()=>onCard?.(p)}/>)}</div>
 </div>;
 return <div className="battlefield">
   {row('CREATURES',groups.creature,'creature-row')}
   {groups.other.length>0&&row('PERMANENTS',groups.other,'other-row')}
   {row('LANDS',groups.land,'land-row')}
 </div>
}