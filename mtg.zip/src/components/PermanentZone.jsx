
import React from "react";
import Card from "./Card";

export default function PermanentZone({label,cards,battlefield,onCard,selectedIds=[],playableIds=[],hover}){
  return <section className="perm-zone">
    <label>{label}</label>
    <div className="perm-row">
      {cards.length?cards.map(c=><Card key={c.id} card={c} battlefield={battlefield}
        selected={selectedIds.includes(c.id)} playable={playableIds.includes(c.id)}
        onClick={()=>onCard?.(c)}
        onHover={hover.show} onMove={hover.move} onLeave={hover.hide}/>)
      :<div className="zone-empty">—</div>}
    </div>
  </section>
}
