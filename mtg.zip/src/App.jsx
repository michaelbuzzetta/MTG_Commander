import React,{useState}from'react';
import db0 from './data/cardDatabase.json' with {type:'json'};
import decks from './data/decks/index.js';
import {GameEngine}from'./engine/GameEngine.js';
import{AIController}from'./ai/AIController.js';
import{Battlefield}from'./components/Battlefield.jsx';
import{Card}from'./components/Card.jsx';
import'./styles.css';

const PHASE_UI={
 UNTAP:{label:'Untap',mode:'TURN',help:'Your permanents untap automatically.'},
 UPKEEP:{label:'Upkeep',mode:'TURN',help:'Upkeep triggers resolve here.'},
 DRAW:{label:'Draw',mode:'TURN',help:'Draw a card for the turn.'},
 PRECOMBAT_MAIN:{label:'Main Phase',mode:'PLAY',help:'Play a land, cast creatures and spells, or activate mana abilities.'},
 BEGIN_COMBAT:{label:'Beginning of Combat',mode:'COMBAT',help:'Combat is beginning. Resolve any beginning-of-combat effects.'},
 DECLARE_ATTACKERS:{label:'Choose Attackers',mode:'ATTACK',help:'Click your creatures to select attackers, then confirm.'},
 DECLARE_BLOCKERS:{label:'Choose Blockers',mode:'DEFEND',help:'Select an attacking creature, then choose creatures to block it.'},
 COMBAT_DAMAGE:{label:'Combat Damage',mode:'COMBAT',help:'Combat damage is being assigned and resolved.'},
 END_COMBAT:{label:'End of Combat',mode:'COMBAT',help:'Combat has ended. Continue to your second main phase.'},
 POSTCOMBAT_MAIN:{label:'Second Main Phase',mode:'PLAY',help:'Play a land if available, cast creatures and spells, or activate abilities.'},
 END:{label:'End Step',mode:'TURN',help:'Resolve end-step effects, then pass the turn.'},
 CLEANUP:{label:'Cleanup',mode:'TURN',help:'Damage clears and hand-size cleanup occurs.'}
};
function PhaseBanner({state,attackers,blockTarget}){
 const ui=PHASE_UI[state.phase]||{label:state.phase.replaceAll('_',' '),mode:'TURN',help:'Continue the current step.'};
 const yours=state.activePlayer==='player';
 let detail=ui.help;
 if(state.phase==='DECLARE_ATTACKERS'&&yours)detail=`${attackers.length} attacker${attackers.length===1?'':'s'} selected. ${ui.help}`;
 if(state.phase==='DECLARE_BLOCKERS'&&!yours)detail=blockTarget?'Now click one of your creatures to assign it as a blocker.':ui.help;
 return <section className={`phase-banner mode-${ui.mode.toLowerCase()}`}>
   <div className="phase-owner">{yours?'YOUR TURN':'OPPONENT TURN'}</div>
   <div className="phase-main"><span className="phase-kicker">{ui.mode}</span><strong>{ui.label}</strong><span>{detail}</span></div>
   <div className="turn-chip">TURN {state.turn}</div>
 </section>
}
export default function App(){
 const[choice,setChoice]=useState(decks[0].id),[engine,setEngine]=useState(null),[,redraw]=useState(0),[attackers,setAttackers]=useState([]),[blockTarget,setBlockTarget]=useState(null),[blockers,setBlockers]=useState({});
 const refresh=()=>redraw(x=>x+1);
 const start=()=>{const mine=decks.find(d=>d.id===choice),others=decks.filter(d=>d.id!==choice),aiDeck=others[Math.floor(Math.random()*others.length)];const e=new GameEngine(mine,aiDeck,db0);e.start();setEngine(e);setAttackers([]);setBlockTarget(null);setBlockers({})};
 if(!engine)return <main className="setup"><div className="setup-panel"><div className="brand-mark">✦</div><h1>MTG AI Trainer</h1><p>Commander practice table</p><label>Choose your deck</label><select value={choice} onChange={e=>setChoice(e.target.value)}>{decks.map(d=><option value={d.id} key={d.id}>{d.name}</option>)}</select><button className="primary" onClick={start}>Start Match</button></div></main>;
 const s=engine.state,p=s.players.player,a=s.players.ai;
 const runAI=()=>{let guard=0;while(!s.winner&&s.priorityPlayer==='ai'&&guard++<100){const ai=new AIController(engine);const action=ai.choose();if(!action)break;engine.perform('ai',action)}};
 const act=(action)=>{try{engine.perform('player',action);runAI();refresh()}catch(err){alert(err.message)}};
 const clickOwnPermanent=perm=>{
   if(s.phase==='DECLARE_ATTACKERS'&&s.activePlayer==='player'){setAttackers(xs=>xs.includes(perm.instanceId)?xs.filter(x=>x!==perm.instanceId):[...xs,perm.instanceId]);return;}
   if(s.phase==='DECLARE_BLOCKERS'&&s.activePlayer==='ai'&&blockTarget){setBlockers(m=>({...m,[blockTarget]:[...(m[blockTarget]||[]).filter(x=>x!==perm.instanceId),perm.instanceId]}));return;}
   const manaAction=engine.getLegalActions('player').find(x=>x.type==='ACTIVATE_MANA'&&x.permanentId===perm.instanceId);if(manaAction)act(manaAction);
 };
 const clickAI=perm=>{if(s.phase==='DECLARE_BLOCKERS'&&s.activePlayer==='ai'&&s.combat.attackers.includes(perm.instanceId))setBlockTarget(perm.instanceId)};
 const next=()=>{
   if(s.phase==='DECLARE_ATTACKERS'&&s.activePlayer==='player'){act({type:'DECLARE_ATTACKERS',attackers});setAttackers([]);return;}
   if(s.phase==='DECLARE_BLOCKERS'&&s.activePlayer==='ai'){act({type:'DECLARE_BLOCKERS',blockers});setBlockers({});setBlockTarget(null);return;}
   act({type:'PASS_PRIORITY'});
 };
 const castCommander=()=>{const c=p.command[0];if(!c)return;const x=engine.getLegalActions('player').find(a=>a.cardInstanceId===c.instanceId);if(x)act(x)};
 const buttonText=s.phase==='DECLARE_ATTACKERS'?'Confirm Attackers':s.phase==='DECLARE_BLOCKERS'?'Confirm Blockers':s.phase==='PRECOMBAT_MAIN'||s.phase==='POSTCOMBAT_MAIN'?'Continue to Next Step':'Pass / Continue';
 const playerSelected=id=>attackers.includes(id)||Object.values(blockers).flat().includes(id);
 return <main className="game-shell">
  <PhaseBanner state={s} attackers={attackers} blockTarget={blockTarget}/>
  <div className="table">
   <section className="player-strip opponent">
    <div className="identity"><span className="avatar">AI</span><div><b>Opponent</b><small>{a.hand.length} cards in hand</small></div></div>
    <div className="life">{a.life}<span>♥</span></div>
    <div className="zone-counts"><span>Library <b>{a.library.length}</b></span><span>Graveyard <b>{a.graveyard.length}</b></span></div>
   </section>

   <section className="command-slot opponent-command"><span>COMMANDER</span>{a.command.map(c=><Card key={c.instanceId} perm={c} def={engine.db[c.cardId]}/>)}</section>

   <section className="battle-zone opponent-zone">
    <Battlefield player={a} db={engine.db} onCard={clickAI} selected={id=>id===blockTarget||s.combat.attackers.includes(id)} />
   </section>

   <section className="center-line">
    <div className="stack-panel"><span>STACK</span><b>{s.stack.length?s.stack.map(x=>engine.db[x.card?.cardId]?.name||'Triggered ability').join(' → '):'Empty'}</b></div>
   </section>

   <section className="battle-zone player-zone">
    <Battlefield player={p} db={engine.db} onCard={clickOwnPermanent} selected={playerSelected}/>
   </section>

   <section className="command-slot player-command"><span>COMMANDER</span>{p.command.map(c=><Card key={c.instanceId} perm={c} def={engine.db[c.cardId]} onClick={castCommander}/>)}</section>

   <section className="player-strip self">
    <div className="identity"><span className="avatar">YOU</span><div><b>Player</b><small>{p.hand.length} cards in hand</small></div></div>
    <div className="life">{p.life}<span>♥</span></div>
    <div className="mana"><span>W <b>{p.manaPool.W}</b></span><span>U <b>{p.manaPool.U}</b></span><span>B <b>{p.manaPool.B}</b></span><span>R <b>{p.manaPool.R}</b></span><span>G <b>{p.manaPool.G}</b></span><span>C <b>{p.manaPool.C}</b></span></div>
   </section>
  </div>

  <section className="hand-tray">
   <div className="hand-label"><b>YOUR HAND</b><span>Click a highlighted playable card to cast it</span></div>
   <div className="hand-cards">{p.hand.map(c=>{const legal=engine.getLegalActions('player').some(a=>a.cardInstanceId===c.instanceId);return <Card key={c.instanceId} perm={c} def={engine.db[c.cardId]} selected={legal} onClick={()=>{const x=engine.getLegalActions('player').find(a=>a.cardInstanceId===c.instanceId);if(x)act(x)}}/>})}</div>
  </section>

  <footer className="action-bar">
   <div className="action-context"><b>{(PHASE_UI[s.phase]||{}).label||s.phase}</b><span>{s.activePlayer==='player'?'You have priority':'Opponent has priority'}</span></div>
   <button className="primary action-button" onClick={next}>{buttonText}</button>
   <div className="resources"><span>Graveyard <b>{p.graveyard.length}</b></span><span>Library <b>{p.library.length}</b></span></div>
  </footer>
  {s.winner&&<div className="winner"><div>{s.winner==='player'?'Victory':'Defeat'}</div></div>}
 </main>
}