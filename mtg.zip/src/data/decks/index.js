import d0 from './explorers.json' with { type: 'json' };
import d1 from './avatar.json' with { type: 'json' };
import d2 from './three-brothers.json' with { type: 'json' };
import d3 from './smaug.json' with { type: 'json' };
import d4 from './poseidon.json' with { type: 'json' };
import d5 from './blech.json' with { type: 'json' };
export default [d0,d1,d2,d3,d4,d5];
