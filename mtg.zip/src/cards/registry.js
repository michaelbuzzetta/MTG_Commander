import {loadCardDatabase} from "../database/CardDatabase";
import {DECKS,parseDeckList} from "./decks";
import {fetchCollection,searchCards} from "./scryfall";
import blechOverrides from "./custom-blech-overrides.json";
import poseidonOverrides from "./custom-poseidon-overrides.json";

let nextId=1;

function classify(typeLine=""){
  if(typeLine.includes("Land"))return "Land";
  if(typeLine.includes("Creature"))return "Creature";
  if(typeLine.includes("Artifact"))return "Artifact";
  if(typeLine.includes("Enchantment"))return "Enchantment";
  if(typeLine.includes("Instant"))return "Instant";
  if(typeLine.includes("Sorcery"))return "Sorcery";
  return "Other";
}
function normalizeOverride(raw){
  if(!raw)return null;
  const cardType=classify(raw.typeLine||"");
  return {
    name:raw.name,manaCost:raw.manaCost||"",manaValue:Number(raw.manaValue||0),
    type:cardType,cardType,typeLine:raw.typeLine||"",
    power:Number.parseInt(raw.power)||0,toughness:Number.parseInt(raw.toughness)||0,
    oracleText:raw.rulesSummary||"",keywords:raw.keywordsOrTags||[],
    colors:[],colorIdentity:[],producedMana:[],image:raw.image||"",
    interactions:raw.interactions||[],custom:true
  };
}
const customMap={
  ...Object.fromEntries(Object.entries(blechOverrides).map(([k,v])=>[k,normalizeOverride(v)])),
  ...Object.fromEntries(Object.entries(poseidonOverrides).map(([k,v])=>[k,normalizeOverride(v)]))
};
function resolve(map,name){
  if(customMap[name])return customMap[name];
  if(map?.[name])return map[name];
  const front=name?.split(" // ")[0];
  if(map?.[front])return map[front];
  return Object.values(map||{}).find(c=>c?.name===name||c?.name?.startsWith(front+" //"))||null;
}
export function freshInstance(base,owner){
  return {...structuredClone(base),id:`c${nextId++}`,owner,controller:owner,zone:"library",
    tapped:false,summoningSick:(base.type||base.cardType)==="Creature",
    counters:{"+1/+1":0,"-1/-1":0},damage:0,token:false,attachedTo:null,revealed:false};
}

async function tryLocal(deckId,owner){
  try{
    const db=await loadCardDatabase();
    const d=db.decks?.[deckId];
    if(!d?.commander||!Array.isArray(d.cards)||d.cards.length<90)return null;
    const commander=db.cards?.[d.commander];
    if(!commander)return null;
    const bases=d.cards.map(n=>db.cards?.[n]);
    if(bases.some(x=>!x))return null;
    return {config:d,commander:freshInstance(commander,owner),cards:bases.map(c=>freshInstance(c,owner))};
  }catch{return null}
}

async function buildFromEmbedded(deckId,owner){
  const cfg=DECKS[deckId];
  if(!cfg)throw new Error(`Unknown deck: ${deckId}`);
  let commanderBase=null,bases=[];

  if(cfg.list){
    const names=parseDeckList(cfg.list);
    const officialNames=names.filter(n=>!customMap[n]);
    const lookup=officialNames.length?await fetchCollection(officialNames):{};
    commanderBase=resolve(lookup,cfg.commander);
    let skipped=false;
    for(const name of names){
      if(name===cfg.commander&&!skipped){skipped=true;continue}
      const c=resolve(lookup,name);
      if(c)bases.push(c);
      else console.warn("Unresolved card:",name);
    }
  }else{
    // Avatar / Theros decks are generated from their themed Scryfall pools.
    const seedNames=[cfg.commander,...(cfg.dynamic.featured||[]),...cfg.dynamic.basics.map(x=>x[0])];
    const lookup=await fetchCollection(seedNames);
    commanderBase=resolve(lookup,cfg.commander);
    const pool=await searchCards(cfg.dynamic.query);
    const chosen=[];
    for(const n of cfg.dynamic.featured||[]){
      const c=resolve(lookup,n);if(c&&!chosen.some(x=>x.name===c.name))chosen.push(c);
    }
    for(const c of pool){
      if(chosen.length>=cfg.dynamic.nonlands)break;
      if(c.name===commanderBase?.name||chosen.some(x=>x.name===c.name))continue;
      chosen.push(c);
    }
    bases=[...chosen];
    for(const [name,count] of cfg.dynamic.basics){
      const b=resolve(lookup,name);
      if(b)for(let i=0;i<count;i++)bases.push(b);
    }
  }

  if(!commanderBase){
    throw new Error(`Could not load commander "${cfg.commander}". Check your connection.`);
  }
  if(bases.length<80){
    throw new Error(`${cfg.name} loaded only ${bases.length} cards. Card metadata could not be resolved.`);
  }
  while(bases.length<99){
    const filler=bases.find(c=>(c.type||c.cardType)==="Land")||bases[0];
    bases.push(filler);
  }
  return {
    config:{id:cfg.id,name:cfg.name,subtitle:cfg.subtitle,icon:cfg.icon,commander:cfg.commander},
    commander:freshInstance(commanderBase,owner),
    cards:bases.slice(0,99).map(c=>freshInstance(c,owner))
  };
}

export async function buildDeck(deckId,owner){
  const local=await tryLocal(deckId,owner);
  if(local)return local;
  return buildFromEmbedded(deckId,owner);
}
