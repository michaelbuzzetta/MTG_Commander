const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const HEADERS={"Accept":"application/json"};

export function imageOf(card){
  return card.image_uris?.normal || card.card_faces?.[0]?.image_uris?.normal || "";
}
function classifyType(typeLine=""){
  if(typeLine.includes("Land"))return "Land";
  if(typeLine.includes("Creature"))return "Creature";
  if(typeLine.includes("Artifact"))return "Artifact";
  if(typeLine.includes("Enchantment"))return "Enchantment";
  if(typeLine.includes("Planeswalker"))return "Planeswalker";
  if(typeLine.includes("Instant"))return "Instant";
  if(typeLine.includes("Sorcery"))return "Sorcery";
  return "Other";
}
export function normalizeCard(c){
  const f=c.card_faces?.[0]||c;
  const typeLine=c.type_line||f.type_line||"";
  const cardType=classifyType(typeLine);
  return {
    scryfallId:c.id,oracleId:c.oracle_id,name:c.name,
    manaCost:f.mana_cost||c.mana_cost||"",manaValue:Number(c.mana_value||0),
    colors:c.colors||f.colors||[],colorIdentity:c.color_identity||[],
    type:cardType,cardType,typeLine,
    oracleText:f.oracle_text||c.oracle_text||"",
    power:Number.parseInt(f.power)||0,toughness:Number.parseInt(f.toughness)||0,
    loyalty:f.loyalty||null,keywords:c.keywords||[],image:imageOf(c),
    producedMana:c.produced_mana||[],interactions:[]
  };
}
async function namedLookup(name){
  const exact=name.includes(" // ")?name.split(" // ")[0]:name;
  for(let attempt=0;attempt<4;attempt++){
    const res=await fetch("https://api.scryfall.com/cards/named?exact="+encodeURIComponent(exact),{headers:HEADERS});
    if(res.ok)return normalizeCard(await res.json());
    if(res.status===429){await sleep(500*(attempt+1));continue}
    return null;
  }
  return null;
}
export async function fetchCollection(names){
  const unique=[...new Set(names)];
  const map={};
  for(let i=0;i<unique.length;i+=75){
    const part=unique.slice(i,i+75);
    const ids=part.map(name=>({name:name.includes(" // ")?name.split(" // ")[0]:name}));
    const res=await fetch("https://api.scryfall.com/cards/collection",{
      method:"POST",
      headers:{...HEADERS,"Content-Type":"application/json"},
      body:JSON.stringify({identifiers:ids})
    });
    if(res.ok){
      const data=await res.json();
      for(const raw of data.data){
        const c=normalizeCard(raw);map[c.name]=c;
        // Also index front-face name for MDFC/split-style deck-list resolution.
        map[c.name.split(" // ")[0]]=c;
      }
    }else{
      // Slow fallback; one failed name won't stop the match.
      for(const name of part){
        if(map[name])continue;
        const c=await namedLookup(name);
        if(c){map[name]=c;map[c.name]=c}
        await sleep(90);
      }
    }
    await sleep(90);
  }
  return map;
}
export async function searchCards(query){
  const all=[];
  let url="https://api.scryfall.com/cards/search?q="+encodeURIComponent(query)+"&unique=cards&order=edhrec";
  while(url&&all.length<130){
    const res=await fetch(url,{headers:HEADERS});
    if(!res.ok)throw new Error(`Card search failed (${res.status}).`);
    const data=await res.json();
    all.push(...data.data.map(normalizeCard));
    url=data.has_more?data.next_page:null;
    if(url)await sleep(120);
  }
  return all;
}
