const imageCache=new Map();

function frontFaceName(name=""){
  return name.includes(" // ")?name.split(" // ")[0]:name;
}

export async function resolveCardImage(card){
  if(!card) return "";
  if(card.image) return card.image;
  if(imageCache.has(card.name)) return imageCache.get(card.name);

  try{
    const exact=frontFaceName(card.name);
    const res=await fetch(
      "https://api.scryfall.com/cards/named?exact="+encodeURIComponent(exact),
      {headers:{"Accept":"application/json"}}
    );
    if(!res.ok){
      imageCache.set(card.name,"");
      return "";
    }
    const data=await res.json();
    const image=
      data.image_uris?.normal ||
      data.card_faces?.[0]?.image_uris?.normal ||
      "";
    imageCache.set(card.name,image);
    return image;
  }catch{
    imageCache.set(card.name,"");
    return "";
  }
}
