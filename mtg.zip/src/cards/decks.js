
export const DECKS = {
  explorers: {
    id: "explorers",
    name: "Explorers of the Deep",
    subtitle: "Hakbal Merfolk",
    icon: "🌊",
    commander: "Hakbal of the Surging Soul",
    list: `
1 Hakbal of the Surging Soul
1 Benthic Biomancer
1 Cold-Eyed Selkie
1 Deepfathom Echo
1 Deeproot Elite
1 Deeproot Historian
1 Emperor Mihail II
1 Evolution Sage
1 Herald of Secret Streams
1 Kiora's Follower
1 Kopala, Warden of Waves
1 Kumena, Tyrant of Orazca
1 Master of the Pearl Trident
1 Merfolk Cave-Diver
1 Merfolk Mistbinder
1 Merfolk Skydiver
1 Merfolk Sovereign
1 Merrow Reejerey
1 Metallic Mimic
1 Mist Dancer
1 Nicanzil, Current Conductor
1 Realmwalker
1 Roaming Throne
1 Seafloor Oracle
1 Singer of Swift Rivers
1 Stonybrook Banneret
1 Surgespanner
1 Svyelun of Sea and Sky
1 Tatyova, Benthic Druid
1 Thieving Skydiver
1 Topography Tracker
1 Vodalian Hexcatcher
1 Zegana, Utopian Speaker
1 Arcane Signet
1 Simic Signet
1 Sol Ring
1 Swiftfoot Boots
1 Vanquisher's Banner
1 Aetherize
1 Beast Within
1 Counterspell
1 Growth Spiral
1 Inspiring Call
1 Quandrix Command
1 Rapid Hybridization
1 Ripples of Potential
1 Spell Pierce
1 Swan Song
1 Cultivate
1 Explore
1 Kodama's Reach
1 Raise the Palisade
1 Ravenform
1 Wave Goodbye
1 Branching Evolution
1 Court of Garenbrig
1 Deeproot Pilgrimage
1 Deeproot Waters
1 Hardened Scales
1 Kindred Discovery
1 Merrow Commerce
1 Reflections of Littjara
1 Simic Ascendancy
1 Command Tower
1 Dreamroot Cascade
1 Exotic Orchard
1 Flooded Grove
10 Forest
1 Hinterland Harbor
13 Island
1 Overflowing Basin
1 Path of Ancestry
1 Rejuvenating Springs
1 Reliquary Tower
1 Secluded Courtyard
1 Unclaimed Territory
1 Vineglimmer Snarl
1 Waterlogged Grove
1 Yavimaya Coast
`
  },

  avatar: {
    id: "avatar",
    name: "Avatar: The Last Airbender",
    subtitle: "Avatar Aang • Four Elements",
    icon: "🌪️",
    commander: "Avatar Aang",
    dynamic: {
      query: "set:tla legal:commander -t:land -is:extra",
      nonlands: 62,
      basics: [["Plains",8],["Island",8],["Swamp",7],["Mountain",7],["Forest",7]]
    }
  },

  olympus: {
    id: "olympus",
    name: "The Three Greek Brothers",
    subtitle: "Zeus • Poseidon • Hades",
    icon: "⚡",
    commander: "Esika, God of the Tree",
    dynamic: {
      query: "(set:ths OR set:bng OR set:jou OR set:thb) legal:commander -t:land -is:extra",
      nonlands: 62,
      featured: ["Heliod, Sun-Crowned","Thassa, Deep-Dwelling","Erebos, Bleak-Hearted"],
      basics: [["Plains",8],["Island",8],["Swamp",7],["Mountain",7],["Forest",7]]
    }
  },

  smaug: {
    id: "smaug",
    name: "Smaug's Treasure Hoard",
    subtitle: "Smaug • Dragons • Treasure",
    icon: "🐉",
    commander: "Smaug, Wicked Worm",
    list: `
1 Smaug, Wicked Worm
1 Academy Manufactor
1 Bladewing the Risen
1 Cavern-Hoard Dragon
1 Chiss-Goria, Forge Tyrant
1 Furnace Hellkite
1 Goldlust Triad
1 Goldspan Dragon
1 Harvester of Souls
1 Hellkite Tyrant
1 Imskir Iron-Eater
1 Ingenious Artillerist
1 Kardur, Doomscourge
1 Magda, Brazen Outlaw
1 Mahadi, Emporium Master
1 Marionette Apprentice
1 Marionette Master
1 Mirkwood Bats
1 Morbid Opportunist
1 Nadier's Nightblade
1 Noxious Gearhulk
1 Reckless Fireweaver
1 Roaming Throne
1 Smaug the Magnificent
1 Solemn Simulacrum
1 Sunshot Militia
1 Weftstalker Ardent
1 Xorn
1 Chaos Warp
1 Deadly Rollick
1 Rakdos Charm
1 Wild Magic Surge
1 Withering Torment
1 Blasphemous Act
1 Damnation
1 Exsanguinate
1 Ghirapur Aether Grid
1 Phyrexian Arena
1 Rain of Riches
1 Revel in Riches
1 Underhanded Designs
1 Adaptive Omnitool
1 Aetherflux Reservoir
1 Amulet of Vigor
1 Arcane Signet
1 Basilisk Collar
1 Conjurer's Closet
1 Coveted Jewel
1 Cranial Plating
1 Cranial Ram
1 Fellwar Stone
1 Gilded Lotus
1 Howling Mine
1 Inspiring Statuary
1 Mycosynth Lattice
1 Nettlecyst
1 Panharmonicon
1 Rakdos Signet
1 Shadowspear
1 Sol Ring
1 Talisman of Indulgence
1 Temple Bell
13 Mountain
13 Swamp
1 Blazemire Verge
1 Blood Crypt
1 Buried Ruin
1 Command Tower
1 Dragonskull Summit
1 Exotic Orchard
1 Foreboding Ruins
1 Haunted Ridge
1 Inventors' Fair
1 Luxury Suite
1 Rogue's Passage
1 Smoldering Marsh
`
  },
  poseidonOlympians: {
    id: "poseidonOlympians",
    name: "Poseidon & the Olympians",
    subtitle: "Sisay • Greek Pantheon • Sea Monsters",
    icon: "🔱",
    commander: "Sisay, Weatherlight Captain",
    list: `
1 Sisay, Weatherlight Captain
1 Thassa, God of the Sea
1 Heliod, Sun-Crowned
1 Purphoros, God of the Forge
1 Nylea, God of the Hunt
1 Erebos, God of the Dead
1 Ephara, God of the Polis
1 Kruphix, God of Horizons
1 Karametra, God of Harvests
1 Xenagos, God of Revels
1 Iroas, God of Victory
1 Athreos, God of Passage
1 Keranos, God of Storms
1 Pharika, God of Affliction
1 Mogis, God of Slaughter
1 Phenax, God of Deception
1 Kiora, Sovereign of the Deep
1 Kiora's Follower
1 Arixmethes, Slumbering Isle
1 Serpent of Yawning Depths
1 Koma, Cosmos Serpent
1 Koma, World-Eater
1 Spawning Kraken
1 Scourge of Fleets
1 Jodah, the Unifier
1 Esika, God of the Tree
1 Inga and Esika
1 Shalai, Voice of Plenty
1 Halana and Alena, Partners
1 Reki, the History of Kamigawa
1 Kethis, the Hidden Hand
1 Shanid, Sleepers' Scourge
1 Heroes' Podium
1 Flowering of the White Tree
1 Day of Destiny
1 The Great Henge
1 Tribute to the World Tree
1 Branching Evolution
1 Bard Class
1 Relic of Legends
1 Primevals' Glorious Rebirth
1 Annie Joins Up
1 Sol Ring
1 Arcane Signet
1 Chromatic Lantern
1 Birds of Paradise
1 Delighted Halfling
1 Faeburrow Elder
1 Cultivate
1 Three Visits
1 Guardian Project
1 Garruk's Uprising
1 Up the Beanstalk
1 Rhystic Study
1 Mystic Remora
1 Swords to Plowshares
1 Beast Within
1 Anguished Unmaking
1 Assassin's Trophy
1 Cyclonic Rift
1 Heroic Intervention
1 Teferi's Protection
1 Urza's Ruinous Blast
1 Farewell
1 Command Tower
1 The World Tree
1 Plaza of Heroes
1 Path of Ancestry
1 Exotic Orchard
1 Reflecting Pool
1 City of Brass
1 Mana Confluence
1 Breeding Pool
1 Temple Garden
1 Hallowed Fountain
1 Watery Grave
1 Blood Crypt
1 Stomping Ground
1 Overgrown Tomb
1 Sacred Foundry
1 Steam Vents
1 Godless Shrine
1 Spara's Headquarters
1 Raffine's Tower
1 Xander's Lounge
1 Ziatora's Proving Ground
1 Jetmir's Garden
1 Flooded Strand
1 Polluted Delta
1 Bloodstained Mire
1 Wooded Foothills
1 Windswept Heath
1 Forest
1 Forest
1 Island
1 Island
1 Plains
1 Plains
1 Mountain
1 Swamp
`
  }
,
  blech: {
    id: "blech",
    name: "Blech's Loafing Swarm",
    subtitle: "Blech • Lifegain • Pest Swarm",
    icon: "🐛",
    commander: "Blech, Loafing Pest",
    list: `
1 Blech, Loafing Pest
1 Blex, Vexing Pest // Search for Blex
1 Beledros Witherbloom
1 Bogwater Lumaret
1 Overgrown Pest
1 Pest Rescuer
1 Caustic Caterpillar
1 Deep-Cavern Bat
1 Mirkwood Bats
1 Starscape Cleric
1 Scute Swarm
1 Iridescent Hornbeetle
1 Hornet Queen
1 Haywire Mite
1 Twitching Doll
1 Arasta of the Endless Web
1 Ishkanah, Grafwidow
1 Nyx Weaver
1 Ohran Frostfang
1 Hooded Hydra
1 Winding Constrictor
1 Sedgemoor Witch
1 Springheart Nantuko
1 Essence Warden
1 Prosperous Innkeeper
1 Kazandu Nectarpot
1 Pristine Talisman
1 Shadowspear
1 The Great Henge
1 Essence Pulse
1 Hardened Scales
1 Branching Evolution
1 Ozolith, the Shattered Spire
1 Corpsejack Menace
1 Doubling Season
1 The Ozolith
1 Inspiring Call
1 Pest Infestation
1 Pest Summoning
1 Hunt for Specimens
1 Tend the Pests
1 Blight Mound
1 Nuisance Engine
1 Pestilent Cauldron // Restorative Burst
1 Skullclamp
1 Greater Good
1 Garruk's Uprising
1 Moldervine Reclamation
1 Guardian Project
1 Return of the Wildspeaker
1 Well of Lost Dreams
1 Sol Ring
1 Arcane Signet
1 Nature's Lore
1 Three Visits
1 Farseek
1 Kodama's Reach
1 Sakura-Tribe Elder
1 Cultivate
1 Assassin's Trophy
1 Beast Within
1 Tear Asunder
1 Heroic Intervention
1 Golgari Charm
1 Toxic Deluge
1 Putrefy
1 Command Tower
1 Overgrown Tomb
1 Woodland Cemetery
1 Deathcap Glade
1 Llanowar Wastes
1 Undergrowth Stadium
1 Necroblossom Snarl
1 Temple of Malady
1 Golgari Rot Farm
1 Tainted Wood
1 Underground Mortuary
1 Festering Thicket
1 Swarmyard
1 Three Tree City
1 High Market
1 Rogue's Passage
1 Reliquary Tower
1 Bojuka Bog
9 Forest
7 Swamp
`
  },

};

export function parseDeckList(text){
  const names = [];
  text.trim().split(/\r?\n/).forEach(line => {
    const m = line.trim().match(/^(\d+)\s+(.+)$/);
    if(!m) return;
    const count = Number(m[1]);
    for(let i=0;i<count;i++) names.push(m[2].trim());
  });
  return names;
}
