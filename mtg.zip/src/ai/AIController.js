import { isType } from '../engine/utils.js';
export class AIController{
 constructor(engine,id='ai'){this.engine=engine;this.id=id;}
 choose(){const e=this.engine,s=e.state;if(s.priorityPlayer!==this.id)return null;const acts=e.getLegalActions(this.id);if(!acts.length)return null;
  const land=acts.find(a=>a.type==='PLAY_LAND');if(land)return land;
  const mana=acts.find(a=>a.type==='ACTIVATE_MANA');const castables=acts.filter(a=>['CAST_SPELL','CAST_COMMANDER'].includes(a.type));if(castables.length)return castables.sort((a,b)=>this.score(b)-this.score(a))[0];if(mana&&this.shouldMakeMana())return mana;
  if(s.phase==='DECLARE_ATTACKERS'&&s.activePlayer===this.id){const attackers=e.combat.legalAttackers(this.id).filter(a=>this.attackScore(a)>0).map(a=>a.instanceId);return {type:'DECLARE_ATTACKERS',attackers};}
  if(s.phase==='DECLARE_BLOCKERS'&&s.activePlayer!==this.id){const map={};const blockers=[...s.players[this.id].battlefield].filter(x=>isType(e.db[x.cardId],'Creature')&&!x.tapped);for(const aid of s.combat.attackers){const a=e.findPermanent(aid);const b=blockers.find(x=>e.combat.canBlock(x,a));if(b){map[aid]=[b.instanceId];blockers.splice(blockers.indexOf(b),1);}}return {type:'DECLARE_BLOCKERS',blockers:map};}
  return acts.find(a=>a.type==='PASS_PRIORITY')||acts[0];}
 shouldMakeMana(){const p=this.engine.state.players[this.id];return p.hand.some(c=>!isType(this.engine.db[c.cardId],'Land'));}
 score(a){const c=this.engine.state.players[this.id].hand.concat(this.engine.state.players[this.id].command).find(x=>x.instanceId===a.cardInstanceId),d=this.engine.db[c?.cardId];return (d?.manaValue||0)+(isType(d,'Creature')?2:0)+(d?.abilities?.length||0);}
 attackScore(p){const st=this.engine.static.derivedStats(p);return st.power>0?st.power:0;}
 step(){const a=this.choose();if(a)this.engine.perform(this.id,a);return a;}
 run(max=100){let n=0;while(n++<max&&!this.engine.state.winner){if(this.engine.state.priorityPlayer!==this.id)break;const a=this.step();if(!a)break;}return n;}
}
