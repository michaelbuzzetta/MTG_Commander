
import {getLegalActions,dispatch} from "../engine/GameEngine";

export function chooseAIAction(state){
  const acts=getLegalActions(state,"ai");
  if(!acts.length) return null;

  const byType=t=>acts.filter(a=>a.type===t);

  if(state.step==="MULLIGAN") return null;
  if(state.step==="DECLARE_BLOCKERS"){
    const block=byType("ASSIGN_BLOCK")[0];
    return block || byType("CONFIRM_BLOCKS")[0];
  }
  if(state.step==="DECLARE_ATTACKERS"){
    const toggles=byType("TOGGLE_ATTACKER");
    if(toggles.length){
      const untoggled=toggles.find(a=>!state.combat.attackers.includes(a.cardId));
      if(untoggled) return untoggled;
    }
    return byType("CONFIRM_ATTACKERS")[0];
  }

  const activation=byType("ACTIVATE_PERMANENT")[0]||byType("ACTIVATE_TOKEN")[0];
  if(activation&&Math.random()<0.3)return activation;

  const land=byType("PLAY_LAND")[0];
  if(land) return land;

  const casts=[...byType("CAST_COMMANDER"),...byType("CAST")];
  if(casts.length){
    casts.sort((a,b)=>{
      const ca=(state.players.ai.hand.find(c=>c.id===a.cardId)||state.players.ai.command.find(c=>c.id===a.cardId));
      const cb=(state.players.ai.hand.find(c=>c.id===b.cardId)||state.players.ai.command.find(c=>c.id===b.cardId));
      return (cb?.manaValue||0)-(ca?.manaValue||0);
    });
    return casts[0];
  }

  if(state.priority==="ai") return byType("PASS_PRIORITY")[0] || null;
  return byType("ADVANCE_STEP")[0] || null;
}

export function runAIUntilUserDecision(state,max=80){
  let s=state;

  for(let i=0;i<max;i++){
    if(s.winner || s.step==="MULLIGAN") break;

    // Human decision point: stop whenever the human has priority.
    if(s.priority==="you") break;

    const action=chooseAIAction(s);
    if(!action) break;

    s=dispatch(s,action,"ai");

    // After an AI action, if priority moves to the user, let the UI/autopass
    // decide whether to interrupt or immediately return it.
    if(s.priority==="you") break;
  }

  return s;
}
