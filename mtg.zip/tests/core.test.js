import test from'node:test';import assert from'node:assert/strict';import{engine,db,decks,putBattlefield}from'./helpers.js';import{ManaEngine}from'../src/engine/ManaEngine.js';
test('all six decks are 100-card Commander decks',()=>{assert.equal(decks.length,6);for(const d of decks){assert.equal(d.cardCount,100);assert.equal(d.cards.reduce((n,x)=>n+x.quantity,0),100);assert.ok(db[d.commander]);}});
test('game starts at 40 life with 7-card hands and commanders',()=>{const e=engine();for(const p of Object.values(e.state.players)){assert.equal(p.life,40);assert.equal(p.hand.length,7);assert.equal(p.command.length,1);assert.equal(p.library.length,92);}});
test('Commander mulligan gives first mulligan free, then bottoms cards',()=>{const e=engine();e.mulligan('player');assert.equal(e.state.players.player.hand.length,7);e.mulligan('player');assert.equal(e.state.players.player.hand.length,6);assert.equal(e.state.players.player.mulligans,2)});
test('mana engine enforces colored and generic costs',()=>{const p={manaPool:{W:0,U:1,B:0,R:0,G:2,C:1}};assert.ok(ManaEngine.canPay(p,'{2}{U}{G}'));assert.equal(ManaEngine.canPay(p,'{B}'),false);assert.ok(ManaEngine.pay(p,'{2}{U}{G}'));assert.equal(Object.values(p.manaPool).reduce((a,b)=>a+b,0),0)});
test('lands tap for mana and cannot tap twice',()=>{const e=engine(),land=putBattlefield(e,'player','island');const a=db.island.abilities[0];e.activateMana('player',land.instanceId,a);assert.equal(e.state.players.player.manaPool.U,1);assert.throws(()=>e.activateMana('player',land.instanceId,a));});
test('commander tax increments by two per cast',()=>{const e=engine(),p=e.state.players.player,c=p.command[0];p.manaPool={W:0,U:10,B:0,R:0,G:10,C:10};e.cast('player',c.instanceId);assert.equal(p.commanderTax,2);});
test('replacement effects stack counters',()=>{const e=engine();putBattlefield(e,'player','hardened-scales');putBattlefield(e,'player','branching-evolution');const t=putBattlefield(e,'player','grizzly-bears');e.effects.addCounters('player',t,'+1/+1',1);assert.equal(t.counters['+1/+1'],4)});
test('doubling season doubles token creation',()=>{const e=engine();putBattlefield(e,'player','doubling-season');const before=e.state.players.player.battlefield.length;e.effects.createToken('player',{name:'Pest',typeLine:'Creature — Pest',power:1,toughness:1,subtypes:['Pest']},2);assert.equal(e.state.players.player.battlefield.length-before,4)});
test('academy manufactor makes three utility tokens',()=>{const e=engine();putBattlefield(e,'player','academy-manufactor');e.effects.createToken('player',{name:'Treasure',typeLine:'Artifact — Treasure'},1);const names=e.state.players.player.battlefield.map(x=>e.db[x.cardId]?.name);assert.ok(names.includes('Treasure')&&names.includes('Food')&&names.includes('Clue'))});
test('state based actions kill lethal creature',()=>{const e=engine(),c=putBattlefield(e,'player','grizzly-bears');c.damageMarked=2;e.stateBasedActions();assert.equal(e.findPermanent(c.instanceId),null);assert.ok(e.state.players.player.graveyard.some(x=>x.instanceId===c.instanceId))});
test('indestructible ignores destroy',()=>{const e=engine(),c=putBattlefield(e,'player','indestructible-god');assert.equal(e.destroy(c),false);assert.ok(e.findPermanent(c.instanceId))});
test('life <=0 loses game',()=>{const e=engine();e.changeLife('ai',-40);assert.equal(e.state.winner,'player')});
test('21 commander damage loses game',()=>{const e=engine(),c=putBattlefield(e,'player','hakbal',{isCommander:true});e.dealDamageToPlayer('ai',21,c);assert.equal(e.state.winner,'player')});

test('commander returns to command zone when destroyed',()=>{const e=engine(),p=e.state.players.player,c=p.command.shift();c.zone='battlefield';c.controller='player';p.battlefield.push(c);e.destroy(c);assert.ok(p.command.some(x=>x.instanceId===c.instanceId));});

test('untapped lands count toward castability before mana is manually floated',()=>{
 const e=engine(),p=e.state.players.player;
 p.hand=[];
 const spell={instanceId:'spell-test',cardId:'merfolk-mistbinder',owner:'player',controller:'player',zone:'hand',tapped:false,summoningSick:false,counters:{},damageMarked:0,modifiers:{power:0,toughness:0,keywords:[]}};
 p.hand.push(spell); putBattlefield(e,'player','forest'); putBattlefield(e,'player','island');
 e.state.phase='PRECOMBAT_MAIN'; e.state.activePlayer='player'; e.state.priorityPlayer='player'; e.state.stack=[];
 assert.ok(e.getLegalActions('player').some(a=>a.type==='CAST_SPELL'&&a.cardInstanceId===spell.instanceId));
});

test('casting automatically taps appropriate lands and puts spell on stack',()=>{
 const e=engine(),p=e.state.players.player;
 p.hand=[];
 const spell={instanceId:'spell-test-2',cardId:'merfolk-mistbinder',owner:'player',controller:'player',zone:'hand',tapped:false,summoningSick:false,counters:{},damageMarked:0,modifiers:{power:0,toughness:0,keywords:[]}};
 p.hand.push(spell); const f=putBattlefield(e,'player','forest'); const i=putBattlefield(e,'player','island');
 e.state.phase='PRECOMBAT_MAIN'; e.state.activePlayer='player'; e.state.priorityPlayer='player'; e.state.stack=[];
 e.cast('player',spell.instanceId);
 assert.equal(f.tapped,true); assert.equal(i.tapped,true); assert.equal(e.state.stack.at(-1).card.instanceId,spell.instanceId);
});

test('generic costs auto-tap enough sources without requiring manual mana activation',()=>{
 const e=engine(),p=e.state.players.player;
 p.hand=[];
 const spell={instanceId:'spell-test-3',cardId:'divination',owner:'player',controller:'player',zone:'hand',tapped:false,summoningSick:false,counters:{},damageMarked:0,modifiers:{power:0,toughness:0,keywords:[]}};
 p.hand.push(spell); putBattlefield(e,'player','island'); putBattlefield(e,'player','forest'); putBattlefield(e,'player','forest');
 e.state.phase='PRECOMBAT_MAIN'; e.state.activePlayer='player'; e.state.priorityPlayer='player'; e.state.stack=[];
 assert.ok(e.canCast('player',spell)); e.cast('player',spell.instanceId);
 assert.equal(p.battlefield.filter(x=>x.tapped).length,3);
});
